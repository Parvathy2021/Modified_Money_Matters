package org.moneymatters.mm_BackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
