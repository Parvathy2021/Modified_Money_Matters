package org.moneymatters.mm_BackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MmBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(MmBackEndApplication.class, args);
	}

}
